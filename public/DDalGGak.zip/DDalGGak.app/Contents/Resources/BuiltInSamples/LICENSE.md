# DDalGGak Built-In Samples

The built-in keyboard samples are short multi-sample excerpts generated from BigSoundBank recordings by Joseph SARDIN.

Source recordings:

- `blue-01.wav` through `blue-06.wav`: Quick Keyboard, sound 1734, https://bigsoundbank.com/quick-keyboard-s1734.html
- `brown-01.wav` through `brown-06.wav`: Computer Keyboard, sound 0229, https://bigsoundbank.com/computer-keyboard-s0229.html
- `red-01.wav` through `red-06.wav`: Quick iMac Keyboard, sound 1731, https://bigsoundbank.com/quick-imac-keyboard-s1731.html
- `thock-01.wav` through `thock-06.wav`: Slow Keyboard, sound 1733, https://bigsoundbank.com/slow-keyboard-s1733.html

The source pages state CC0/public-domain-equivalent terms. Attribution is not required by that license, but the source and author are kept here for auditability.
